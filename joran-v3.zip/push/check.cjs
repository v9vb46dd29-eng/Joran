/* Joran — Push-Prüfung für GitHub Actions. Keine KI: feste Regeln aus core.js.
   Liest config.json (Einstellungen aus der App), schickt Nachrichten über ntfy.sh, merkt sich Gesendetes in push/state.json. */
"use strict";
const fs = require("fs"), path = require("path");
const C = require("../core.js");

const ROOT = path.join(__dirname, "..");
const readJSON = (p, d) => { try{ return JSON.parse(fs.readFileSync(p, "utf8")); }catch(e){ return d; } };
const cfg = C.merge(readJSON(path.join(ROOT, "config.json"), {}));
const STATE_P = path.join(__dirname, "state.json");
const state = readJSON(STATE_P, {sent:{}});
state.sent = state.sent || {};
const before = JSON.stringify(state);
const TOPIC = process.env.NTFY_TOPIC;
const NOW = process.env.JORAN_NOW ? new Date(process.env.JORAN_NOW) : new Date();
const PAGE = process.env.JORAN_URL || "https://v9vb46dd29-eng.github.io/Joran/";

async function send(title, message, priority, tags){
  console.log(`PUSH [${priority}] ${title}: ${message}`);
  if(!TOPIC){ console.log("  (kein NTFY_TOPIC gesetzt — nur Log)"); return; }
  const r = await fetch("https://ntfy.sh/", {method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({topic:TOPIC, title, message, priority, tags, click:PAGE})});
  if(!r.ok) throw new Error("ntfy HTTP "+r.status);
}

async function main(){
  const today = C.localDay(0, NOW), hour = C.localHour(NOW);

  /* Lebenszeichen: verhindert, dass GitHub den Zeitplan nach 60 Tagen ohne Aktivität abschaltet */
  const hb = state.heartbeat ? (NOW - new Date(state.heartbeat))/864e5 : 99;
  if(hb>25) state.heartbeat = NOW.toISOString();

  if(process.env.JORAN_TEST==="1"){
    await send("Joran: Test", `Push funktioniert. Push ist in der App ${cfg.push?"eingeschaltet":"ausgeschaltet"}. Schwelle ${cfg.T} kn.`, 3, ["white_check_mark"]);
    return finish();
  }
  if(!cfg.push){ console.log("Push ausgeschaltet (config.json)."); return finish(); }
  if(hour<6 || hour>=21){ console.log("Ruhezeit."); return finish(); }

  const D = await C.fetchAll(cfg, {ens:false, jura:false});
  const nModels = Object.keys(D.models).length;
  console.log(`Modelle: ${nModels}/4, Fehler:`, D.err);
  const [h0,h1] = C.WINS[cfg.win];

  /* 1) Prognose: heute bis Fensterbeginn, morgen ab 16 Uhr — je Tag einmal, bei Aufstufung erneut */
  if(cfg.pushForecast && nModels){
    for(const off of [0,1]){
      if(off===0 && hour>=h0) continue;
      if(off===1 && hour<16) continue;
      const day = C.localDay(off, NOW), s = C.summarize(D.models, day, cfg);
      const key = "fc:"+day, prev = state.sent[key];
      if(s.level>=cfg.cut && (!prev || s.level>prev.level)){
        await send(`${off?"Morgen":"Heute"}: Wind ${C.LEVELS[s.level]}`, C.describe(s, cfg), s.level>=4?4:3, ["wind_face"]);
        state.sent[key] = {level:s.level, at:NOW.toISOString()};
      } else if(off===0 && prev && prev.level>=cfg.cut && s.level<cfg.cut && !state.sent["fx:"+day]){
        await send("Heute: Entwarnung", `Die Modelle sehen die Schwelle nicht mehr. ${C.describe(s, cfg)||"Kaum Wind."}`, 2, ["cloud"]);
        state.sent["fx:"+day] = {at:NOW.toISOString()};
      }
    }
  }

  /* 2) Messung: Upwind-Signal oder Regel E, im Fenster ab 2 h vorher — einmal pro Tag */
  if(cfg.pushLive && hour>=h0-2 && hour<=h1){
    const nc = C.nowcast(D.stations, cfg, NOW);
    if(nc.front.length && (state.sent["live:"+today] || state.sent["fc:"+today]) && !state.sent["front:"+today]){
      await send("Böenfront — nicht rausfahren", nc.front.map(x=>`${x.up.name}: ${x.f.join(", ")}`).join("; "), 5, ["warning"]);
      state.sent["front:"+today] = {at:NOW.toISOString()};
    } else if(!state.sent["live:"+today] && !nc.front.length && (nc.eOk || nc.trusted.length)){
      const parts = [];
      if(nc.eOk) parts.push(`Joran-Regel E in Cressier: ${C.r0(nc.e.mean30)} kn seit ${C.hhmm(nc.e.since)}`);
      nc.trusted.forEach(x=>{ if(nc.eOk && x.up.abk==="crm") return;
        parts.push(`${x.up.name} ${C.r0(x.u.mean30)} kn ${x.u.sys?x.u.sys.name:C.card(x.u.last.dir)}${x.u.since?" seit "+C.hhmm(x.u.since):""}${x.u.trust==null?" (ungeprüft)":""}`); });
      await send("Wind kommt — Messung", parts.join("; "), 4, ["ocean"]);
      state.sent["live:"+today] = {at:NOW.toISOString()};
    }
  }
  return finish();
}
function finish(){
  const lim = C.localDay(-10, NOW);
  Object.keys(state.sent).forEach(k=>{ if(k.split(":")[1] < lim) delete state.sent[k]; });
  if(JSON.stringify(state)!==before){ fs.writeFileSync(STATE_P, JSON.stringify(state, null, 1)+"\n"); console.log("state.json aktualisiert."); }
}
main().catch(e=>{ console.error(e); finish(); process.exitCode = 1; });
